# test_sorting_algorithms.py

import pytest
from insertion_sort import insertion_sort
from bubble_sort import bubble_sort
from selection_sort import selection_sort

# Test cases for Insertion Sort
def test_insertion_sort_empty_list():
    assert insertion_sort([]) == []

def test_insertion_sort_sorted_list():
    assert insertion_sort([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

def test_insertion_sort_reverse_list():
    assert insertion_sort([5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]

def test_insertion_sort_mixed_list():
    assert insertion_sort([3, 1, 4, 2, 5]) == [1, 2, 3, 4, 5]

# Test cases for Bubble Sort
def test_bubble_sort_empty_list():
    assert bubble_sort([]) == []

def test_bubble_sort_sorted_list():
    assert bubble_sort([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

def test_bubble_sort_reverse_list():
    assert bubble_sort([5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]

def test_bubble_sort_mixed_list():
    assert bubble_sort([3, 1, 4, 2, 5]) == [1, 2, 3, 4, 5]

# Test cases for Selection Sort
def test_selection_sort_empty_list():
    assert selection_sort([]) == []

def test_selection_sort_sorted_list():
    assert selection_sort([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

def test_selection_sort_reverse_list():
    assert selection_sort([5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]

def test_selection_sort_mixed_list():
    assert selection_sort([3, 1, 4, 2, 5]) == [1, 2, 3, 4, 5]
