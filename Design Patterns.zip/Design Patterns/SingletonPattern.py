from abc import ABC, abstractmethod

# Abstract Product: ProgrammingSubject
class ProgrammingSubject(ABC):
    @abstractmethod
    def get_details(self):
        pass

# Concrete Products
class PythonSubject(ProgrammingSubject):
    def get_details(self):
        return "Python is a versatile, interpreted, and high-level programming language."

class CSharpSubject(ProgrammingSubject):
    def get_details(self):
        return "C# is a modern, object-oriented programming language developed by Microsoft."

class JavaSubject(ProgrammingSubject):
    def get_details(self):
        return "Java is a popular, platform-independent programming language known for its robustness."

# Abstract Factory: SubjectFactory
class SubjectFactory(ABC):
    @abstractmethod
    def create_subject(self):
        pass

# Concrete Factories
class PythonFactory(SubjectFactory):
    def create_subject(self):
        return PythonSubject()

class CSharpFactory(SubjectFactory):
    def create_subject(self):
        return CSharpSubject()

class JavaFactory(SubjectFactory):
    def create_subject(self):
        return JavaSubject()

# Client Code
def main():
    subjects = [PythonFactory(), CSharpFactory(), JavaFactory()]

    for factory in subjects:
        subject = factory.create_subject()
        print(subject.get_details())

if __name__ == "__main__":
    main()
